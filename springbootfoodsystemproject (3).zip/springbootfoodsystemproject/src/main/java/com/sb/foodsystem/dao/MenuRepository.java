package com.sb.foodsystem.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.sb.foodsystem.entity.Menu;



public interface MenuRepository  extends JpaRepository<Menu,Long> 
{
	
	//Menu findMenuById(Long id);
    List<Menu> findByRestaurant_Id(Long id);

    void deleteByRestaurant_Id(Long id);


}
