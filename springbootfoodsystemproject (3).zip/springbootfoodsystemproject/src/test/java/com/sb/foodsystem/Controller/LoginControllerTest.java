package com.sb.foodsystem.Controller;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.sb.foodsystem.controller.LoginController;
import com.sb.foodsystem.model.LoginDTO;
import com.sb.foodsystem.service.LoginService;
import com.sb.foodsystem.service.UserService;

public class LoginControllerTest {
	 @Mock
	    private UserService userService;
	    
	    @Mock
	    private LoginService loginService;


	    @InjectMocks
	    private LoginController loginController;

	    @BeforeEach
	    void setUp() {
	        MockitoAnnotations.openMocks(this);
	    }

//	    @Test
//	    void testAdminLogin() {
//	    	// Arrange
//	        LoginDTO loginDTO = new LoginDTO(); // Create a sample LoginDTO
//
//	        // Act
//	    	LoginDTO response = loginController.createLogin(loginDTO);
//	    	 // Assert
//	        assertEquals(HttpStatus.OK, response.getStatusCode());
//	        assertNotNull(response.getBody());
//	        verify(loginService, times(1)).getLoginById(id);
//	    }
//
//	    @Test
//	    void testUserLogin() {
//	        // Act
//	        ResponseEntity<String> response = loginController.userLogin();
//
//	        // Assert
//	        assertEquals(HttpStatus.OK, response.getStatusCode());
//	        assertEquals("User Login", response.getBody());
//	    }
//
//	}
//
//
}
