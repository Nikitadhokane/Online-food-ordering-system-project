package com.sb.foodsystem.Controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.sb.foodsystem.controller.AdminController;
import com.sb.foodsystem.model.AdminDTO;
import com.sb.foodsystem.service.AdminService;

public class AdminControllerTest {
	
		
	@Mock
    private AdminService adminService;

    @InjectMocks
    private AdminController adminController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

   
    @Test
    ResponseEntity<AdminDTO> testGetAdmin() {
        // Arrange
        Long adminId = 1L;
        AdminDTO admin = new AdminDTO(1L, "Ishapatil", "pass123", "isha123@gmail.com", "1234567890");

        when(adminService.getAdminById(adminId));
        return(ResponseEntity.ok(admin));
    }

    @Test
    ResponseEntity<String> testcreateAdmin() {
        // Arrange
    	@SuppressWarnings("unused")
    	 AdminDTO admin = new AdminDTO(1L, "Ishapatil", "pass123", "isha123@gmail.com", "1234567890");

        when(adminService.createAdmin(any(AdminDTO.class)));
        return(ResponseEntity.ok("Admin added successfully."));
    }

    @Test
    ResponseEntity<String> testUpdateAdmin() {
        // Arrange
        Long adminId = 1L;
        AdminDTO admin = new AdminDTO(1L, "Ishapatil", "pass123", "isha123@gmail.com", "1234567890");

        when(adminService.updateAdmin(adminId, admin));
        return(ResponseEntity.ok("Admin updated successfully."));
    }

    @Test
    ResponseEntity<String> testDeleteAdmin() {
        // Arrange
        Long adminId = 1L;

        when(adminService.deleteAdmin(adminId));
        return(ResponseEntity.ok("Admin deleted successfully."));
    }
}

